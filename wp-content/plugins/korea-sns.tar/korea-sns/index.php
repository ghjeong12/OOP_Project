<?php
// Blank file to stop directory browsing.