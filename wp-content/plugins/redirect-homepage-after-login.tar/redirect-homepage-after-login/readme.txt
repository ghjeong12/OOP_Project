=== Redirect Homepage after Login ===
Contributors: tcoder
Tags: login, redirect, admin, login page, homepage
Requires at least: 3.0
Tested up to: 4.7
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will enable to redirect user homepage after login.

== Description ==

This plugin will enable to redirect user homepage after login.


= Plugin Features =

* Only 0.5 KB.
* Easy to use.
* One click to install

== Installation ==

= Installation =

1. Upload 'tcbd-redirect-home-login' folder to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Frequently Asked Questions ==

* For more questions or help, [contact me](mailto:info@tcoderbd.com).

== Changelog ==

= 1.0 =
* Initial release

