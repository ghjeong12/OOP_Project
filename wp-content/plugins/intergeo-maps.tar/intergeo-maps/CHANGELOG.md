
 ### v2.2.0 - 2017-09-25 
 **Changes:** 
 * Improved compatibility with the pro version.
* Fixed various small bugs and ui issues.
 
### 2.1.3 - 28/07/2017
**Changes:** 
- Development

### 2.1.3 - 06/04/2017
**Changes:** 
- Update readme.txt

### 2.1.3 - 31/01/2017
**Changes:** 
- Fixed pro slug of plan option

### 2.1.2 - 22/01/2017
**Changes:** 
- Fixed issue when editing map.

### 2.1.1 - 19/01/2017
**Changes:** 
- Fixed compat with other plugins who are using dashboard widget

### 2.1.0 - 12/01/2017
**Changes:** 
- Release 2.1

### 2.0.0 - 05/01/2017
**Changes:** 
- Refactored for the new options in the pro version

### 1.1.6 - 31/10/2016
**Changes:** 
- Removed freemius support

